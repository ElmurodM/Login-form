<?php
//connect to database
$db=mysqli_connect("localhost","ish","qV2oC4yE0dmY6u","ish");
?>